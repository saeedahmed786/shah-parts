import React from 'react'

const LogoComp = () => {
    return (
        <>
            <h1 className='text-[43px] text-white font-bold'>Shop</h1>
        </>
    )
}

export default LogoComp
