import AdminLayout from '@/components/Layouts/Admin/AdminLayout'
import React from 'react'

const Dashboard = () => {
    return (
        <AdminLayout sidebar>
            Dashboard
        </AdminLayout>
    )
}

export default Dashboard
