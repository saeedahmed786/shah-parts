module.exports = {
    MONGO_URI: 'mongodb://localhost:27017/ShahParts',
    JWT_SECRET: 'kdjkasjqr8239r8kfj939kdjkdjfkwt944039043kjgkwjgkwgwlkg404204wegklgkt42-owpglw4-y34pyo3py0239tfkeit049igkjkvjvw049t09tofjkwrjt034tigdfkjgkdfjg0rt9304fsdkfj04t904gigo',
    JWT_EXPIRE: '24h',
    CLOUDINARY_CLOUD_NAME: 'saeedahmed',
    CLOUDINARY_API_KEY: '633615861791628',
    CLOUDINARY_SECRET_KEY: 'pcu5hDuFK01arwcxuotN3EHXFRc',
    EMAIL: 'ali9656623@gmail.com',
    PASSWORD: "dnrdgeoodzullmnp"
} 
